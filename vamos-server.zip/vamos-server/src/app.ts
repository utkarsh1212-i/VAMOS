import express, { Application } from 'express';
// import cors from 'cors';
// import morgan from 'morgan';
// import helmet from 'helmet';
import * as dotenv from 'dotenv';
// import { errorHandler } from './middlewares/errorHandler'; // Import custom error handler
import routes from './routes'; // Import all routes

// Load environment variables
dotenv.config();

// Create Express app
const app: Application = express();

// Middleware
// app.use(cors()); // Enable CORS
// app.use(morgan('dev')); // Logger middleware
// app.use(helmet()); // Add basic security headers
app.use(express.json()); // Parse JSON request bodies
app.use(express.urlencoded({ extended: true })); // Parse URL-encoded request bodies

// Routes
app.use('/api', routes); // Prefix API routes with /api

// Health Check
app.get('/', (req, res) => {
  res.send('Server is up and running!');
});

// Error Handling Middleware
app.use(errorHandler);

export default app;
