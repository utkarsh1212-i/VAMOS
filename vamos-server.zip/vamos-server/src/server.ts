import { createServer } from 'http';
import { Server } from 'socket.io';
import app from './app'; // Import the Express app
import { connectDB } from './config/db'; // Import DB connection
import { initializeQuizSocket } from './sockets/quizSocket'; // Import WebSocket handlers

const PORT = process.env.PORT || 3000;

(async () => {
  try {
    // Connect to the database
    await connectDB();

    // Create an HTTP server
    const httpServer = createServer(app);

    // Set up WebSocket server
    const io = new Server(httpServer, {
      cors: {
        origin: '*', // Adjust for your frontend origin
        methods: ['GET', 'POST'],
      },
    });

    // Initialize WebSocket handlers
    initializeQuizSocket(io);

    // Start the server
    httpServer.listen(PORT, () => {
      console.log(`Server is running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start the server:', error);
    process.exit(1);
  }
})();
